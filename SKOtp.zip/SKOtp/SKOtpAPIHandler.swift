import Foundation

public protocol SKOtpAPIHandler {
    /// Send an OTP to the user (e.g., via SMS/email)
    func requestOtp(completion: @escaping (Result<Void, Error>) -> Void)

    /// Verify the OTP code entered by the user
    func verifyOtp(_ code: String, completion: @escaping (Result<Bool, Error>) -> Void)
    
    /// Optional async/await support
    func verifyOtp(_ code: String) async throws -> Bool
    func requestOtp() async throws
}

public extension SKOtpAPIHandler {
    func requestOtp(completion: @escaping (Result<Void, Error>) -> Void) {
        Task {
            do {
                try await requestOtp()
                completion(.success(()))
            } catch {
                completion(.failure(error))
            }
        }
    }

    func verifyOtp(_ code: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        Task {
            do {
                let result = try await verifyOtp(code)
                completion(.success(result))
            } catch {
                completion(.failure(error))
            }
        }
    }
}