//
//  SKOtpMode.swift
//  Pods
//
//  Created by IE Mac 05 on 06/06/25.
//


import Foundation

public enum SKOtpMode {
    case local
    case remote
}

public struct SKOtpConfig {
    public let mode: SKOtpMode
    public let baseURL: String
    public let requestOtpEndpoint: String
    public let verifyOtpEndpoint: String

    public init(mode: SKOtpMode = .remote,
                baseURL: String,
                requestOtpEndpoint: String,
                verifyOtpEndpoint: String) {
        self.mode = mode
        self.baseURL = baseURL
        self.requestOtpEndpoint = requestOtpEndpoint
        self.verifyOtpEndpoint = verifyOtpEndpoint
    }
}
