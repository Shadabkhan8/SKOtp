//
//  SKOtpDefaultAPI.swift
//  Pods
//
//  Created by IE Mac 05 on 06/06/25.
//


import Foundation

public struct SKOtpDefaultAPI: SKOtpAPIHandler {
    
    let config: SKOtpConfig

    public init(config: SKOtpConfig) {
        self.config = config
    }

    public func requestOtp(for phone: String) async throws -> Bool {
        guard config.mode == .remote else { return true }

        let url = URL(string: "\(config.baseURL)\(config.requestOtpEndpoint)")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = ["phone": phone]
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }

        return true
    }

    public func verifyOtp(for phone: String, otp: String) async throws -> Bool {
        guard config.mode == .remote else {
            return otp == "123456" // Simulated correct OTP in `.local` mode
        }

        let url = URL(string: "\(config.baseURL)\(config.verifyOtpEndpoint)")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = ["phone": phone, "otp": otp]
        request.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw URLError(.cannotParseResponse)
        }

        return true
    }
}
