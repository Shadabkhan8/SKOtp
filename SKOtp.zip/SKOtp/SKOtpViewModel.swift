//
//  SKOtpViewModel.swift
//  Pods
//
//  Created by IE Mac 05 on 06/06/25.
//


import Foundation
import Combine

public final class SKOtpViewModel: ObservableObject {
    // MARK: - Inputs
    @Published public var phoneNumber: String = ""
    @Published public var otp: String = ""
    @Published public var isLoading: Bool = false

    // MARK: - Dependency
    private let apiHandler: SKOtpAPIHandler

    // MARK: - Hooks
    public var onAPIStart: (() -> Void)?
    public var onAPISuccess: (() -> Void)?
    public var onAPIFailure: ((Error) -> Void)?

    // MARK: - Init
    public init(apiHandler: SKOtpAPIHandler) {
        self.apiHandler = apiHandler
    }

    // MARK: - Request OTP
    @MainActor
    public func requestOtp() async {
        isLoading = true
        onAPIStart?()

        do {
            let success = try await apiHandler.requestOtp(for: phoneNumber)
            if success {
                onAPISuccess?()
            } else {
                throw NSError(domain: "OTP Error", code: 1, userInfo: [NSLocalizedDescriptionKey: "OTP request failed."])
            }
        } catch {
            onAPIFailure?(error)
        }

        isLoading = false
    }

    // MARK: - Verify OTP
    @MainActor
    public func verifyOtp() async {
        isLoading = true
        onAPIStart?()

        do {
            let success = try await apiHandler.verifyOtp(for: phoneNumber, otp: otp)
            if success {
                onAPISuccess?()
            } else {
                throw NSError(domain: "Verification Error", code: 2, userInfo: [NSLocalizedDescriptionKey: "OTP verification failed."])
            }
        } catch {
            onAPIFailure?(error)
        }

        isLoading = false
    }
}
